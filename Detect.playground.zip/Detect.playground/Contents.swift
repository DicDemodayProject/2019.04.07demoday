import UIKit
import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

func faceApi(_ method: String, _ header: String, _ url: String, _ body:Data?) -> URLRequest {
    var request: URLRequest = URLRequest(url: URL(string: "https://eastasia.api.cognitive.microsoft.com/face/v1.0/" + url)!)
    request.httpMethod = method
    request.addValue(header, forHTTPHeaderField: "Content-Type")
    request.addValue("", forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
    request.httpBodyStream = InputStream(data: body!)
    return request
}

func httpReq(_ request: URLRequest) -> (Data?, URLResponse?, Error?) {
    let config = URLSessionConfiguration.default
    let session = URLSession(configuration: config)
    
    var d: Data? = nil
    var r: URLResponse? = nil
    var e: Error? = nil
    let semahore = DispatchSemaphore(value: 0)
    
    let task = session.dataTask(with: request) {(data, response, error) in
        d = data
        r = response
        e = error
        semahore.signal()
    }
    task.resume()
    _ = semahore.wait(timeout: DispatchTime.distantFuture)
    return (d, r, e)
}

struct jsonCodable: Codable {
    let faceId: String
    let faceRectangle: String
}
let url = "detect?returnFaceId=true&returnFaceAttributes=age%2Cgender%2Csmile%2CfacialHair%2Cemotion"
let method = "POST"
let header = "application/octet-stream"

let image = UIImage(named: "01_kogure.jpg")
let imageView = UIImageView(image: image)
let body = imageView.image?.jpegData(compressionQuality: 0.5)
let request = faceApi(method, header, url, body)

var resultData: Data?
var resultResponse: URLResponse?
var resultError: Error?
(resultData, resultResponse, resultError) = httpReq(request)
do{
    let results = try JSONSerialization.jsonObject(with: resultData!) as! Dictionary<String, Any>
    print(results["faceId"] as! String)
    //print(results["faceRectangle"] as! String)
}
